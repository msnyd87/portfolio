#!/bin/bash
echo "🚀 Setting up Matt Snyder Portfolio..."

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  Please create a .env file based on .env.example"
    echo "   Add your RESEND_API_KEY for email functionality"
    cp .env.example .env
fi

echo "✅ Setup complete!"
echo "📖 Run 'npm run dev' to start development server"
echo "🏗️  Run 'npm run build' to build for production"
